# Boostora SMM Panel — Full-Stack Demo

Boostora is a runnable SMM-panel prototype with a responsive customer interface, Express REST API, and persistent SQLite database. It uses mock service data and simulated orders only.

## Included

- Responsive overview dashboard and account balance
- Demo service catalog with platform and text filters
- New-order form with server-side validation and live pricing
- SQLite-backed order history and status tracking
- Simulated order lifecycle: Pending → In progress → Completed
- Demo wallet top-ups and transaction ledger (no payments)
- Admin service enable/disable controls and operational overview
- JSON REST API
- Seed data created automatically on first launch

## Requirements

- Node.js 20 or newer
- npm

## Run locally

```bash
npm install
npm start
```

Open http://localhost:3000.

For development with automatic server restart:

```bash
npm run dev
```

The SQLite database is created at `data/boostora.sqlite` on first launch.

## Demo API

All routes are relative to `http://localhost:3000`.

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/summary` | Balance and dashboard statistics |
| GET | `/api/services` | List active services; supports `platform`, `category`, `q` query params |
| GET | `/api/orders` | List latest orders |
| POST | `/api/orders` | Create a simulated order |
| GET | `/api/wallet` | Balance and transaction history |
| POST | `/api/wallet/demo-topup` | Add simulated funds |
| GET | `/api/admin/overview` | Demo admin data |
| PATCH | `/api/admin/services/:id` | Enable or disable a service |

### Create a simulated order

```bash
curl -X POST http://localhost:3000/api/orders \
  -H 'Content-Type: application/json' \
  -d '{"serviceId":1,"targetUrl":"https://example.com/profile","quantity":100}'
```

### Add demo funds

```bash
curl -X POST http://localhost:3000/api/wallet/demo-topup \
  -H 'Content-Type: application/json' \
  -d '{"amount":500}'
```

## Important limitations before production

This is a development prototype, not a production-ready money-handling platform.

- There is no user authentication or multi-tenant account separation. The demo balance is shared by the local instance.
- Admin endpoints are intentionally unauthenticated for local testing. Do not expose them publicly.
- Wallet credits are simulated and do not process payments.
- Orders never contact social networks or an external provider. A timer simulates their status progression.
- Provider credentials, payment webhooks, real fulfillment, customer support, email, refunds, and deployment automation are not configured.
- Before production, add secure authentication and authorization, per-user wallet ledgers, CSRF protections where relevant, request rate limiting, robust input validation, audit logging, database backups, payment-webhook verification, secret management, monitoring, and tests.
- Use only authorized integrations and review the relevant social-platform rules before enabling services.

## Suggested next milestones

1. Authentication, roles, and per-user data ownership.
2. Secure provider adapter with encrypted secrets, timeouts, retries, and idempotency.
3. Payment gateway integration using verified server-side webhooks.
4. Background job queue for fulfillment and status synchronization.
5. Admin authorization, audit trail, automated tests, and deployment configuration.

## Project layout

```text
boostora-smm-panel/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── src/
│   ├── db.js
│   └── server.js
├── package.json
└── README.md
```
