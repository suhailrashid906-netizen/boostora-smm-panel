import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";

const dataDir = path.resolve("data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "boostora.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL,
    category TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    rate REAL NOT NULL,
    min_qty INTEGER NOT NULL,
    max_qty INTEGER NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_id INTEGER NOT NULL REFERENCES services(id),
    service_name TEXT NOT NULL,
    platform TEXT NOT NULL,
    target_url TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    charge REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending',
    progress INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    amount REAL NOT NULL,
    description TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

const count = db.prepare("SELECT COUNT(*) AS count FROM services").get().count;
if (count === 0) {
  const seed = [
    ["Instagram", "Followers", "Instagram followers · demo", "Simulated delivery for demo profiles. No real engagement is sent.", 1.25, 50, 10000],
    ["Instagram", "Likes", "Instagram post likes · demo", "Mock service for interface testing only.", 0.45, 10, 50000],
    ["Instagram", "Views", "Instagram reel views · demo", "Mock service for interface testing only.", 0.08, 100, 100000],
    ["TikTok", "Views", "TikTok video views · demo", "Simulated order lifecycle; no platform activity occurs.", 0.12, 100, 100000],
    ["TikTok", "Likes", "TikTok likes · demo", "Mock service for interface testing only.", 0.65, 10, 25000],
    ["YouTube", "Views", "YouTube video views · demo", "Mock service for interface testing only.", 2.50, 100, 10000],
    ["YouTube", "Subscribers", "YouTube subscribers · demo", "Mock service for interface testing only.", 8.00, 10, 1000],
    ["Facebook", "Page Likes", "Facebook page likes · demo", "Mock service for interface testing only.", 1.10, 25, 10000]
  ];
  const insert = db.prepare(`INSERT INTO services (platform, category, name, description, rate, min_qty, max_qty)
    VALUES (?, ?, ?, ?, ?, ?, ?)`);
  const transaction = db.transaction((rows) => rows.forEach((row) => insert.run(...row)));
  transaction(seed);
}

const balance = db.prepare("SELECT value FROM settings WHERE key = 'demo_balance'").get();
if (!balance) db.prepare("INSERT INTO settings (key, value) VALUES ('demo_balance', '1000.00')").run();

export default db;
