import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import db from "./db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.resolve(__dirname, "../public")));

const getBalance = () => Number(db.prepare("SELECT value FROM settings WHERE key = 'demo_balance'").get()?.value || 0);
const setBalance = (value) => db.prepare("UPDATE settings SET value = ? WHERE key = 'demo_balance'").run(value.toFixed(2));
const publicOrder = (row) => ({
  id: row.id, serviceId: row.service_id, serviceName: row.service_name,
  platform: row.platform, targetUrl: row.target_url, quantity: row.quantity,
  charge: row.charge, status: row.status, progress: row.progress,
  createdAt: row.created_at, updatedAt: row.updated_at
});

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "Boostora", mode: "demo" }));

app.get("/api/summary", (_req, res) => {
  const orderStats = db.prepare(`SELECT COUNT(*) total,
    SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) completed,
    SUM(CASE WHEN status IN ('Pending','In progress') THEN 1 ELSE 0 END) active,
    COALESCE(SUM(charge),0) spent FROM orders`).get();
  const recent = db.prepare("SELECT * FROM orders ORDER BY id DESC LIMIT 5").all().map(publicOrder);
  res.json({ balance: getBalance(), ...orderStats, recent });
});

app.get("/api/services", (req, res) => {
  const { platform, category, q } = req.query;
  let sql = "SELECT * FROM services WHERE active = 1";
  const params = [];
  if (platform && platform !== "All platforms") { sql += " AND platform = ?"; params.push(platform); }
  if (category && category !== "All categories") { sql += " AND category = ?"; params.push(category); }
  if (q) { sql += " AND (name LIKE ? OR platform LIKE ? OR category LIKE ?)"; const like = `%${q}%`; params.push(like, like, like); }
  sql += " ORDER BY platform, category, id";
  res.json(db.prepare(sql).all(...params));
});

app.get("/api/orders", (_req, res) => {
  const orders = db.prepare("SELECT * FROM orders ORDER BY id DESC LIMIT 200").all().map(publicOrder);
  res.json(orders);
});

app.post("/api/orders", (req, res) => {
  const { serviceId, targetUrl, quantity } = req.body || {};
  const service = db.prepare("SELECT * FROM services WHERE id = ? AND active = 1").get(Number(serviceId));
  const qty = Number(quantity);
  if (!service) return res.status(400).json({ error: "Choose an available service." });
  if (!Number.isInteger(qty) || qty < service.min_qty || qty > service.max_qty) {
    return res.status(400).json({ error: `Quantity must be between ${service.min_qty.toLocaleString()} and ${service.max_qty.toLocaleString()}.` });
  }
  let url;
  try { url = new URL(String(targetUrl || "")); } catch { return res.status(400).json({ error: "Enter a valid public URL beginning with https://." }); }
  if (!["http:", "https:"].includes(url.protocol)) return res.status(400).json({ error: "Only http and https URLs are supported." });

  const charge = Math.round((service.rate * qty / 1000) * 100) / 100;
  if (charge <= 0) return res.status(400).json({ error: "Order amount must be greater than zero." });
  const createOrder = db.transaction(() => {
    const balance = getBalance();
    if (balance < charge) throw new Error("INSUFFICIENT_BALANCE");
    setBalance(balance - charge);
    const result = db.prepare(`INSERT INTO orders
      (service_id, service_name, platform, target_url, quantity, charge, status, progress)
      VALUES (?, ?, ?, ?, ?, ?, 'Pending', 0)`)
      .run(service.id, service.name, service.platform, url.toString(), qty, charge);
    db.prepare("INSERT INTO transactions (type, amount, description) VALUES ('debit', ?, ?)")
      .run(charge, `Demo order #${result.lastInsertRowid}`);
    return Number(result.lastInsertRowid);
  });

  try {
    const id = createOrder();
    // Demo-only lifecycle. In production this would be a queue worker calling a provider API.
    setTimeout(() => {
      const row = db.prepare("SELECT status FROM orders WHERE id = ?").get(id);
      if (!row || row.status !== "Pending") return;
      db.prepare("UPDATE orders SET status = 'In progress', progress = 35, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(id);
      setTimeout(() => {
        const current = db.prepare("SELECT status FROM orders WHERE id = ?").get(id);
        if (!current || current.status !== "In progress") return;
        db.prepare("UPDATE orders SET status = 'Completed', progress = 100, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(id);
      }, 12000);
    }, 2500);
    res.status(201).json({ message: "Demo order created. No real social media activity will occur.", order: publicOrder(db.prepare("SELECT * FROM orders WHERE id = ?").get(id)), balance: getBalance() });
  } catch (error) {
    if (error.message === "INSUFFICIENT_BALANCE") return res.status(400).json({ error: "Insufficient demo balance. Use the Add demo funds button in the Wallet." });
    console.error(error);
    res.status(500).json({ error: "Could not create the order." });
  }
});

app.get("/api/wallet", (_req, res) => {
  const transactions = db.prepare("SELECT id, type, amount, description, created_at AS createdAt FROM transactions ORDER BY id DESC LIMIT 100").all();
  res.json({ balance: getBalance(), transactions });
});

app.post("/api/wallet/demo-topup", (req, res) => {
  const amount = Number(req.body?.amount);
  if (!Number.isFinite(amount) || amount < 1 || amount > 10000) return res.status(400).json({ error: "Demo top-up must be between ₹1 and ₹10,000." });
  const topUp = db.transaction(() => {
    const balance = getBalance() + amount;
    setBalance(balance);
    db.prepare("INSERT INTO transactions (type, amount, description) VALUES ('credit', ?, 'Demo wallet top-up (no payment taken)')").run(amount);
    return balance;
  });
  res.json({ balance: topUp() , message: "Demo funds added. No real payment was processed." });
});

app.get("/api/admin/overview", (_req, res) => {
  const services = db.prepare("SELECT * FROM services ORDER BY id").all();
  const orders = db.prepare("SELECT COUNT(*) count, COALESCE(SUM(charge),0) revenue FROM orders").get();
  res.json({ services, orders, balance: getBalance(), demo: true });
});

app.patch("/api/admin/services/:id", (req, res) => {
  const active = req.body?.active;
  if (typeof active !== "boolean") return res.status(400).json({ error: "active must be true or false." });
  const result = db.prepare("UPDATE services SET active = ? WHERE id = ?").run(active ? 1 : 0, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Service not found." });
  res.json({ ok: true });
});

app.get("*", (_req, res) => res.sendFile(path.resolve(__dirname, "../public/index.html")));

app.listen(PORT, () => console.log(`Boostora demo running at http://localhost:${PORT}`));
