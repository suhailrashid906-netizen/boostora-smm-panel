const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const money = (n) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 2 }).format(Number(n || 0));
const dateTime = (v) => v ? new Date(v.replace(" ", "T") + (v.includes("Z") ? "" : "Z")).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "—";
let services = [];
let orders = [];
let activeView = "overview";

async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed. Please try again.");
  return data;
}
function toast(message, type = "success") {
  const node = document.createElement("div"); node.className = `toast ${type}`; node.textContent = message;
  $("#toast-region").append(node); setTimeout(() => node.remove(), 4200);
}
function statusClass(status) { return status.toLowerCase().replace(/\s+/g, "-"); }
function statusPill(status) { return `<span class="status ${statusClass(status)}">${status}</span>`; }
function platformInitial(platform) { return ({ Instagram: "IG", TikTok: "TT", YouTube: "YT", Facebook: "f" })[platform] || "S"; }
function emptyState(title, text, icon = "↗") { return `<div class="empty-state"><div class="empty-icon">${icon}</div><strong>${title}</strong>${text}</div>`; }

function orderTable(items) {
  if (!items.length) return emptyState("No orders yet", "Your submitted demo orders will appear here.", "↗");
  return `<table class="data-table"><thead><tr><th>ORDER ID</th><th>SERVICE</th><th>QUANTITY</th><th>CHARGE</th><th>STATUS</th></tr></thead><tbody>${items.map(o => `<tr><td class="order-id">#${o.id}</td><td class="service-cell" title="${escapeHtml(o.serviceName)}">${escapeHtml(o.serviceName)}</td><td>${Number(o.quantity).toLocaleString("en-IN")}</td><td>${money(o.charge)}</td><td>${statusPill(o.status)}</td></tr>`).join("")}</tbody></table>`;
}
function escapeHtml(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" })[c]); }

async function refreshSummary() {
  const summary = await api("/api/summary");
  $("#stat-balance").textContent = money(summary.balance); $("#order-balance").textContent = money(summary.balance); $("#wallet-balance").textContent = money(summary.balance);
  $("#stat-total").textContent = summary.total || 0; $("#stat-active").textContent = summary.active || 0; $("#stat-completed").textContent = summary.completed || 0;
  $("#recent-orders").innerHTML = orderTable(summary.recent);
}
async function loadServices() {
  services = await api("/api/services");
  renderServiceSelect(); renderServicesGrid(); renderAdminServices();
}
async function loadOrders() {
  orders = await api("/api/orders"); renderOrders(); renderAdminOverview();
}
function renderServiceSelect() {
  const platform = $("#platform-select").value;
  const list = services.filter(s => s.platform === platform);
  $("#service-select").innerHTML = `<option value="">${list.length ? "Choose a service" : "Choose a platform first"}</option>` + list.map(s => `<option value="${s.id}">${escapeHtml(s.name)} — ${money(s.rate)} / 1k</option>`).join("");
  $("#service-select").disabled = !list.length;
  updateSelectedService();
}
function updateSelectedService() {
  const s = services.find(x => x.id === Number($("#service-select").value));
  $("#service-description").textContent = s ? s.description : "Select a service to see its details.";
  $("#quantity").min = s?.min_qty || 1; $("#quantity").max = s?.max_qty || 100000;
  $("#quantity-limits").textContent = s ? `Min ${s.min_qty.toLocaleString()} · Max ${s.max_qty.toLocaleString()}` : "Select a service to see limits";
  $("#side-min").textContent = s ? s.min_qty.toLocaleString() : "—"; $("#side-max").textContent = s ? s.max_qty.toLocaleString() : "—";
  $("#rate-label").textContent = s ? `${money(s.rate)} / 1k` : "—";
  if (s && (Number($("#quantity").value) < s.min_qty || Number($("#quantity").value) > s.max_qty)) $("#quantity").value = s.min_qty;
  updateCharge();
}
function updateCharge() {
  const s = services.find(x => x.id === Number($("#service-select").value));
  const quantity = Number($("#quantity").value || 0);
  $("#quantity-label").textContent = quantity.toLocaleString("en-IN");
  $("#charge-label").textContent = s && quantity > 0 ? money(s.rate * quantity / 1000) : money(0);
}
function renderOrders() {
  const query = ($("#order-search")?.value || "").toLowerCase();
  const status = $("#status-filter")?.value || "All statuses";
  const filtered = orders.filter(o => (status === "All statuses" || o.status === status) && (`${o.id} ${o.serviceName} ${o.targetUrl} ${o.platform}`.toLowerCase().includes(query)));
  $("#all-orders").innerHTML = orderTable(filtered);
  $("#order-count-label").textContent = `${filtered.length} order${filtered.length === 1 ? "" : "s"}`;
}
function renderServicesGrid() {
  const q = ($("#service-search")?.value || "").toLowerCase();
  const platform = $("#service-platform-filter")?.value || "All platforms";
  const filtered = services.filter(s => (platform === "All platforms" || s.platform === platform) && `${s.name} ${s.platform} ${s.category}`.toLowerCase().includes(q));
  $("#services-grid").innerHTML = filtered.length ? filtered.map(s => `<article class="service-card"><div class="platform-icon">${platformInitial(s.platform)}</div><div class="service-card-main"><h3>${escapeHtml(s.name)}</h3><p>${escapeHtml(s.description)}</p><div class="service-meta"><span>${escapeHtml(s.platform)}</span><span>${escapeHtml(s.category)}</span><span>${s.min_qty.toLocaleString()}–${s.max_qty.toLocaleString()}</span></div></div><div class="service-price">${money(s.rate)}<small>per 1,000</small><button class="text-button choose-service" data-service="${s.id}">Select ↗</button></div></article>`).join("") : emptyState("No matching services", "Try another search or platform filter.", "▦");
}
async function renderWallet() {
  const wallet = await api("/api/wallet");
  $("#wallet-balance").textContent = money(wallet.balance);
  $("#transactions-list").innerHTML = wallet.transactions.length ? wallet.transactions.map(t => `<div class="transaction-row"><div class="transaction-icon ${t.type}">${t.type === "credit" ? "＋" : "−"}</div><div class="transaction-main"><strong>${escapeHtml(t.description)}</strong><small>${dateTime(t.createdAt)}</small></div><div class="transaction-amount ${t.type}">${t.type === "credit" ? "+" : "−"}${money(t.amount)}</div></div>`).join("") : emptyState("No transactions yet", "Wallet activity will show up here.", "◈");
}
async function renderAdminOverview() {
  const data = await api("/api/admin/overview");
  $("#admin-service-count").textContent = data.services.length; $("#admin-order-count").textContent = data.orders.count; $("#admin-revenue").textContent = money(data.orders.revenue);
  renderAdminServices(data.services);
}
function renderAdminServices(items) {
  const list = items || services;
  if (!$("#admin-services")) return;
  $("#admin-services").innerHTML = list.map(s => `<div class="admin-service"><div class="platform-icon">${platformInitial(s.platform)}</div><div class="admin-service-main"><strong>${escapeHtml(s.name)}</strong><small>${escapeHtml(s.platform)} · ${money(s.rate)} per 1k · ${s.active ? "Active" : "Disabled"}</small></div><button class="toggle ${s.active ? "enabled" : ""}" data-toggle-service="${s.id}" data-active="${s.active ? "true" : "false"}">${s.active ? "Enabled ✓" : "Disabled"}</button></div>`).join("");
}
function go(view) {
  activeView = view;
  $$(".view").forEach(v => v.classList.toggle("active", v.id === `view-${view}`));
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  const label = ({ overview: "Overview", "new-order": "New order", orders: "My orders", services: "Services", wallet: "Wallet", admin: "Admin tools" })[view] || "Overview";
  $("#page-crumb").textContent = label; $("#sidebar").classList.remove("open");
  if (view === "wallet") renderWallet().catch(e => toast(e.message, "error"));
  if (view === "admin") renderAdminOverview().catch(e => toast(e.message, "error"));
  if (view === "orders") loadOrders().catch(e => toast(e.message, "error"));
  window.scrollTo({ top: 0, behavior: "smooth" });
}
$$("[data-view]").forEach(b => b.addEventListener("click", () => go(b.dataset.view)));
$$("[data-go]").forEach(b => b.addEventListener("click", () => go(b.dataset.go)));
$("#platform-select").addEventListener("change", renderServiceSelect);
$("#service-select").addEventListener("change", updateSelectedService);
$("#quantity").addEventListener("input", updateCharge);
$("#order-search").addEventListener("input", renderOrders);
$("#status-filter").addEventListener("change", renderOrders);
$("#service-search").addEventListener("input", renderServicesGrid);
$("#service-platform-filter").addEventListener("change", renderServicesGrid);
$("#refresh-btn").addEventListener("click", () => Promise.all([refreshSummary(), loadServices(), loadOrders()]).then(() => toast("Dashboard refreshed." )).catch(e => toast(e.message, "error")));
$("#mobile-menu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
$("#banner-dismiss").addEventListener("click", () => $(".demo-banner").remove());
$("#services-grid").addEventListener("click", e => {
  const btn = e.target.closest("[data-service]"); if (!btn) return;
  const service = services.find(s => s.id === Number(btn.dataset.service)); if (!service) return;
  go("new-order"); $("#platform-select").value = service.platform; renderServiceSelect(); $("#service-select").value = String(service.id); updateSelectedService();
});
$("#admin-services").addEventListener("click", async e => {
  const btn = e.target.closest("[data-toggle-service]"); if (!btn) return;
  try {
    await api(`/api/admin/services/${btn.dataset.toggleService}`, { method: "PATCH", body: JSON.stringify({ active: btn.dataset.active !== "true" }) });
    await loadServices(); await renderAdminOverview(); toast("Service availability updated.");
  } catch (err) { toast(err.message, "error"); }
});
$("#order-form").addEventListener("submit", async e => {
  e.preventDefault(); $("#order-error").textContent = "";
  const btn = $("#submit-order"); btn.disabled = true; btn.textContent = "Submitting…";
  try {
    const result = await api("/api/orders", { method: "POST", body: JSON.stringify({ serviceId: Number($("#service-select").value), targetUrl: $("#target-url").value.trim(), quantity: Number($("#quantity").value) }) });
    toast(`Demo order #${result.order.id} created. No real delivery occurred.`);
    $("#target-url").value = "";
    await Promise.all([refreshSummary(), loadOrders(), renderWallet()]);
    go("orders");
    setTimeout(() => Promise.all([refreshSummary(), loadOrders()]).catch(() => {}), 4000);
    setTimeout(() => Promise.all([refreshSummary(), loadOrders()]).catch(() => {}), 16000);
  } catch (err) { $("#order-error").textContent = err.message; }
  finally { btn.disabled = false; btn.innerHTML = "<span>↗</span> Submit demo order"; }
});
$("#topup-form").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const result = await api("/api/wallet/demo-topup", { method: "POST", body: JSON.stringify({ amount: Number($("#topup-amount").value) }) });
    await Promise.all([refreshSummary(), renderWallet()]); toast(result.message);
  } catch (err) { toast(err.message, "error"); }
});
$$("[data-amount]").forEach(b => b.addEventListener("click", () => $("#topup-amount").value = b.dataset.amount));

async function init() {
  try {
    await Promise.all([refreshSummary(), loadServices(), loadOrders()]);
    renderServiceSelect();
    await renderAdminOverview();
  } catch (err) {
    toast(`Could not connect to the demo API: ${err.message}. Make sure the server is running.`, "error");
  }
}
init();
